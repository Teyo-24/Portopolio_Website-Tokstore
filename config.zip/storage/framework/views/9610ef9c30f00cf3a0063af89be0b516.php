<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Tambah Kategori</h1>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <form method="post" action="<?php echo e(route('kategori.update', $kategori->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="mb-3">
                                    <label for="kategori" class="form-label">Nama Kategori</label>
                                    <input type="text" class="form-control" id="kategori" name="nama_kategori"
                                        placeholder="Input Kategori" value="<?php echo e($kategori->nama_kategori); ?>" required>
                                </div>
                                <button type="submit" class="btn btn-primary">Submit</button>
                                <a href="<?php echo e(route('kategori.index')); ?>" class="btn btn-secondary ms-2">Back</a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\portopolio-website-tokstore\resources\views/admin/kategori/edit.blade.php ENDPATH**/ ?>