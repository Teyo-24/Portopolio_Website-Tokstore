<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Ubah Data Barang</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">DataTables</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h3 class="card-title">DataTable with default features</h3>
                        </div>
                        <div class="card-body">
                            <form method="post" action="<?php echo e(route('produk.update', $produk->id)); ?>"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <div class="mb-3">
                                    <label for="gambar" class="form-label">Gambar Produk</label>
                                    <?php if($produk->gambar): ?>
                                        <div class="mb-2">
                                            <img src="<?php echo e(asset('storage/' . $produk->gambar)); ?>" alt="Gambar Produk"
                                                width="150">
                                        </div>
                                    <?php endif; ?>
                                    <input type="file" class="form-control py-1" id="gambar" name="gambar">
                                </div>
                                <div class="mb-3">
                                    <label for="kategori" class="form-label">Kategori</label>
                                    <select class="form-control" id="kategori" name="kategori_id"
                                        aria-label="Default select example" required>
                                        <option selected disabled>Pilih Kategori</option>
                                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"
                                                <?php echo e($item->id == $produk->kategori_id ? 'selected' : ''); ?>>
                                                <?php echo e($item->nama_kategori); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="nama" class="form-label">Nama Produk</label>
                                    <input type="text" class="form-control" id="nama" name="nama"
                                        value="<?php echo e($produk->nama); ?>" placeholder="Input Nama Produk" required>
                                </div>
                                <div class="mb-3">
                                    <label for="harga" class="form-label">Harga Barang</label>
                                    <input type="number" class="form-control" id="harga" name="harga"
                                        value="<?php echo e($produk->harga); ?>" placeholder="Input Harga" required>
                                </div>
                                <div class="mb-3">
                                    <label for="deskripsi" class="form-label">Deskripsi Produk</label>
                                    <textarea class="form-control" name="deskripsi" id="editor" cols="50" rows="10"><?php echo e($produk->deskripsi); ?></textarea>
                                </div>
                                <button type="submit" class="btn btn-primary">Submit</button>
                                <a href="<?php echo e(route('produk.index')); ?>" class="btn btn-secondary ms-2">Back</a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\portopolio-website-tokstore\resources\views/admin/produk/edit.blade.php ENDPATH**/ ?>